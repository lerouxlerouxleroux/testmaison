<?php

session_start();

require_once("constantes.php");
require_once("db.php");
require_once("functions.php");
?>
