<?php
require_once("inc/_init.php");
unset($_SESSION['ferghana_user']);
header("location:index.php");
?>
