    <footer>
    </footer>
</div>

<blockQuote>&copy Dila Abdukarimova 2014</blockQuote>

</body>
</html>

<?php
mysql_close();
?>
